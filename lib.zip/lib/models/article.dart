class Article {
  final String title;
  final String? description;
  final String url;
  final String? image;
  final String publishedAt;
  final String? category;
  final String? author;

  Article({
    required this.title,
    required this.description,
    required this.url,
    required this.image,
    required this.publishedAt,
    required this.category,
    required this.author,
  });

  factory Article.fromJson(Map<String, dynamic> json) {
    return Article(
      title: json['title'] ?? 'Sin título',
      description: json['description'],
      url: json['link'] ?? '',
      image: json['image_url'], // puede ser null
      publishedAt: json['pubDate'] ?? '',
      category: (json['category'] != null && json['category'].isNotEmpty)
          ? json['category'][0]
          : null,
      author: json['creator'] is List && json['creator'].isNotEmpty
          ? json['creator'][0]
          : null,
    );
  }
}
