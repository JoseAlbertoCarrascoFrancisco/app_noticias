import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/article.dart';

class ApiService {
  final String _apiKey = 'pub_fb71f981b0ed49a39621c248dacb8072';
  final String _url =
      'https://newsdata.io/api/1/latest?apikey=pub_fb71f981b0ed49a39621c248dacb8072&language=es';

  Future<List<Article>> fetchArticles() async {
    final response = await http.get(Uri.parse(_url));

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      final articlesJson = data['results'] as List;

      return articlesJson.map((json) => Article.fromJson(json)).toList();
    } else {
      throw Exception('Error al cargar artículos');
    }
  }
}
