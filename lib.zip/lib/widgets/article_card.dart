import 'package:flutter/material.dart';
import '../models/article.dart';

class ArticleCard extends StatelessWidget {
  final Article article;
  final VoidCallback onTap;

  const ArticleCard({
    super.key,
    required this.article,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.all(8),
      child: ListTile(
        leading: article.image != null
            ? Image.network(article.image!, width: 100, fit: BoxFit.cover)
            : const Icon(Icons.image_not_supported),
        title: Text(article.title),
        onTap: onTap,
      ),
    );
  }
}
